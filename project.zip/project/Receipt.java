

import java.util.List;

/**
 * An interface to print the Receipt
 */

public interface Receipt {
	 public String print(GuestUser user);
}
